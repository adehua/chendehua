<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Curl {
	
	protected $_ch;

	function init() 
	{
		$this->_ch = curl_init();
		curl_setopt($this->_ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		curl_setopt($this->_ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($this->_ch, CURLOPT_HEADER, false);
		curl_setopt($this->_ch, CURLOPT_VERBOSE, 1);
		
	}
		
	function send_request($api,$data = NULL) 
	{
		$this->init();
		curl_setopt($this->_ch, CURLOPT_URL, $api);
		curl_setopt($this->_ch, CURLOPT_POST, 1);
		if(is_array($data) && isset($data['cookie_msg']))
		{
			$cookie = 'pt2gguin='.$data['cookie_msg']['pt2gguin'];
			$cookie.= '; uin='.$data['cookie_msg']['uin'];
			$cookie.= '; skey='.$data['cookie_msg']['skey'];
			curl_setopt($this->_ch,CURLOPT_COOKIE,$cookie);
		}
		curl_setopt($this->_ch, CURLOPT_POSTFIELDS, $data);
		$response = curl_exec($this->_ch);
		$status   = curl_getinfo($this->_ch, CURLINFO_HTTP_CODE);
		
		curl_close($this->_ch);

		return $response;
	}

	/**
	 * @method get
	 * @static
	 * @param  {string}
	 * @return {string|boolen}
	 */
	 function get( $url ){
		$this->_ch = curl_init();
		curl_setopt($this->_ch, CURLOPT_URL, $url);
		# curl_setopt($this->_ch, CURLOPT_HEADER, 1);
		curl_setopt($this->_ch, CURLOPT_RETURNTRANSFER, 1);

		curl_setopt($this->_ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($this->_ch, CURLOPT_SSL_VERIFYHOST, FALSE);

		if(!curl_exec($this->_ch)){
			error_log( curl_error ( $this->_ch ));
			$data = '';
		} else {
			$data = curl_multi_getcontent($this->_ch);

		}
		curl_close($this->_ch);
		return $data;
	}

	/**
	 * @method post
	 * @static
	 * @param  {string}        $url URL to post data to
	 * @param  {string|array}  $data Data to be post
	 * @return {string|boolen} Response string or false for failure.
	 */
	 function post( $url, $data ){
		$this->_ch = curl_init();
		curl_setopt( $this->_ch, CURLOPT_URL, $url );
		curl_setopt( $this->_ch, CURLOPT_RETURNTRANSFER, 1 );
		# curl_setopt( $this->_ch, CURLOPT_HEADER, 1);

		curl_setopt( $this->_ch, CURLOPT_SSL_VERIFYPEER, FALSE );
		curl_setopt( $this->_ch, CURLOPT_SSL_VERIFYHOST, FALSE );

		curl_setopt( $this->_ch, CURLOPT_POST, 1 );
		curl_setopt( $this->_ch, CURLOPT_POSTFIELDS, $data );
		$data = curl_exec($this->_ch);
		if(!$data) error_log( curl_error ( $this->_ch ) );
		curl_close( $this->_ch );
		return $data;
	}
}
?>
