<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

$config['store_id'] = "ad646fa70fe13b54119c9057018e9451";
$config['zip_list'] = "http://fun.kid.qq.com/mobapi/mb.php?app=zip_list&act=get_list";
$config['finish_download'] = "http://fun.kid.qq.com/mobapi/mb.php?app=zip_list&act=finish_download";
$config['order_info'] = "http://fun.kid.qq.com/mobapi/mb.php?app=zip_list&act=get_order_info";
$config['pdf_dir'] = "";
$config['package'] = 'http://fun.kid.qq.com/?app=packagefun&act=get_id';	//回传数据接口路径
$config['upgrade'] = 'http://fun.kid.qq.com/?app=upgrade&act=get_id';	//升级接口路径
$config['express'] = array(1,2,3,6,7);//顺丰标快 , EMS , 圆通速递 , 韵达快递 , 申通快递
$config['server_ip'] = '10.22.73.133';//10.22.73.133