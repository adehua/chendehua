<?php  
	if(!defined('BASEPATH')) exit('No direct script access allowed');  

	$config['cache_lifetime']   = 0;  
	$config['caching']  = 0;  
	$config['template_dir'] = APPPATH .'views/default';  
	$config['compile_dir']  = APPPATH .'temps'; 
	$config['cache_dir']    = APPPATH . 'cache';  
	$config['use_sub_dirs'] = false;    //子目录变量(是否在缓存文件夹中生成子目录)  
	$config['left_delimiter']   = '{';
	$config['right_delimiter']  = '}';  
?>  