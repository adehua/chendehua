<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 */

class Upgrade_model extends CI_Model{
    //sql
    public function db_query($sqls){
    	if(count($sqls) > 0){
    		$this->db->trans_start();
    		foreach ($sqls as $k => $sql) {
    			$this->db->query($sql);
    		}
    		$this->db->trans_complete();
    		return true;
    	}else{
    		return false;
    	}
    }
}