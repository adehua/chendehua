<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 */

class Order_express_model extends CI_Model{

    const TBL_ORDER = 'order';
    const TBL_GOODS = 'goods';
    const TBL_STATUS_LOG = 'status_log';

    public function list_data($start = 0, $perpage = 10, $order_number, $start_time, $end_time){
        $this->db->select("*");
        $this->db->from(self::TBL_ORDER);
        //$this->db->join(self::TBL_GOODS.' g','o.order_id = g.order_id', 'inner');
        //$this->db->where("1=1");
        if(!empty($order_number) && strlen($order_number) < 10){    //订单的长度是10位
            $this->db->where('order_number like "%'.$order_number.'%"');
        }else if(!empty($order_number) && strlen($order_number) >= 10){
            $this->db->where('order_number ='.$order_number);
        }
        if($start_time > 0){
            $this->db->where('add_time >='.$start_time);
        }
        if($end_time > 0){
            $this->db->where('add_time <= '.$end_time);
        }
        $this->db->where('status = 25'); //假定装订完成的订单状态是30
        $this->db->order_by("order_id","desc");
        $this->db->limit($perpage, $start);
        $query = $this->db->get();
        return $query->result_array();
        //echo $this->db->last_query();
        //return $query->row_array();
    }

    public function num_rows($order_number, $start_time, $end_time){
        $this->db->select("count(*) as total");
        $this->db->from(self::TBL_ORDER);
        if(!empty($order_number) && strlen($order_number) < 10){
            $this->db->where('order_number like "%'.$order_number.'%"');
        }else if(!empty($order_number) && strlen($order_number) >= 10){
            $this->db->where('order_number ='.$order_number);
        }
        if($start_time > 0){
            $this->db->where('add_time >='.$start_time);
        }
        if($end_time > 0){
            $this->db->where('add_time <= '.$end_time);
        }
        $this->db->where('`status` = 30'); //假定装订完成的订单状态是30
        $this->db->order_by("order_id","desc");
        $query = $this->db->get();
        $data = $query->row_array();
        return $data['total'];
    }
    //获取单个商品
    public function get_goods($order_id){
        $this->db->select("*");
        $this->db->from(self::TBL_GOODS);
        $this->db->where('order_id = '.$order_id);
        $this->db->order_by("goods_id","desc");
        $query = $this->db->get();
        return $query->result_array();
//        return $query->row_array();
    }
    //从单个订单剥离出elid
    public function get_elids($order_id, $elid){
        $this->db->select("elid");
        $this->db->from(self::TBL_GOODS);
        $this->db->where('order_id = '.$order_id);
        $this->db->order_by("goods_id","desc");
        $query = $this->db->get();
        $result = $query->result_array();
        return array_search($elid,array_column($result,"elid"));
    }
    //发货成功
    public function update_order_success($data,$order_id){  
        $condition['order_id'] = $order_id;
        $condition['status'] = 25;
        $id = $this->db->where($condition)->update(self::TBL_ORDER,$data);
        if($id > 0){
            $goods_data = array('status'=>8);
            $goods_condition['order_id'] = $order_id;
            return $this->db->where($goods_condition)->update(self::TBL_GOODS,$goods_data);
        }else{
            return false;
        }
    }
    //打回操作 不修改商品的状态
    public function update_order_error($data, $order_id, $goods){
        $condition['order_id'] = $order_id;
        $condition['status'] = 25;
        $id = $this->db->where($condition)->update(self::TBL_ORDER,$data);
        if($id > 0){
            $goods_data = array('status'=>5);
            $goods_condition['order_id'] = $order_id;
            return $this->db->where("order_id = ".$order_id." and goods_id in (".$goods.")")->update(self::TBL_GOODS,$goods_data);
        }else{
            return false;
        }
    }
    //获取单个订单
    public function get_order($order_id){
        $this->db->select("*");
        $this->db->from(self::TBL_ORDER);
        $this->db->where('order_id = '.$order_id);
        $this->db->order_by("order_id","desc");
        $query = $this->db->get();
        return $query->row_array();
    }
    public function get_goods_all($order_id){
        $this->db->select("goods_id");
        $this->db->from(self::TBL_GOODS);
        $this->db->where('order_id = '.$order_id);
        $this->db->order_by("goods_id","desc");
        $query = $this->db->get();
        return $query->result_array();
    }
    //日志入库
    public function order_log($data){
        return $this->db->insert(self::TBL_STATUS_LOG,$data);
    }
    //扫码
    public function update_goods_barcode($data, $goods_id){
        $condition['goods_id'] = $goods_id;
        return $this->db->where($condition)->update(self::TBL_GOODS,$data);
    }
    
    public function get_one_order_number($order_number){
        $this->db->select("*");
        $this->db->from(self::TBL_ORDER);
        $this->db->where_in("order_number",$order_number);
        $result = $this->db->get();
        return $result->row_array();
    }
    public function get_one_elid($order_id,$elid){
        $this->db->select("*");
        $this->db->from(self::TBL_GOODS);
        $this->db->where_in("order_id",$order_id);
        $this->db->where_in("elid",$elid);
        $result = $this->db->get();
        return $result->row_array();
    }
}