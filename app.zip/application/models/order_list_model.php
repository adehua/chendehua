<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 */

class Order_list_model extends CI_Model{

    const TBL_ORDER = 'order';
    const TBL_GOODS = 'goods';

    public function list_data($start = 0, $perpage = 10, $order_number, $start_time, $end_time){
        $this->db->select("*");
        $this->db->from(self::TBL_ORDER);
        //$this->db->join(self::TBL_GOODS.' g','o.order_id = g.order_id', 'inner');
        //$this->db->where("1=1");
        if(!empty($order_number) && strlen($order_number) < 10){    //订单的长度是10位
            $this->db->where('order_number like "%'.$order_number.'%"');
        }else if(!empty($order_number) && strlen($order_number) >= 10){
            $this->db->where('order_number ='.$order_number);
        }
        if($start_time > 0){
            $this->db->where('add_time >='.$start_time);
        }
        if($end_time > 0){
            $this->db->where('add_time <= '.$end_time);
        }
        $this->db->where_in('status',array(29,30)); //假定已发货的订单状态是30
        $this->db->order_by("status","asc");
        $this->db->order_by("order_id","desc");
        $this->db->limit($perpage, $start);
        $query = $this->db->get();
        return $query->result_array();
        //echo $this->db->last_query();
        //return $query->row_array();
    }

    public function num_rows($order_number, $start_time, $end_time){
        $this->db->select("count(*) as total");
        $this->db->from(self::TBL_ORDER);
        if(!empty($order_number) && strlen($order_number) < 10){
            $this->db->where('order_number like "%'.$order_number.'%"');
        }else if(!empty($order_number) && strlen($order_number) >= 10){
            $this->db->where('order_number ='.$order_number);
        }
        if($start_time > 0){
            $this->db->where('add_time >='.$start_time);
        }
        if($end_time > 0){
            $this->db->where('add_time <= '.$end_time);
        }
        $this->db->where_in('status',array(29,30)); //假定已发货的订单状态是30
        $this->db->order_by("order_id","desc");
        $query = $this->db->get();
        $data = $query->row_array();
        return $data['total'];
    }
    //获取单个商品
    public function get_goods($order_id){
        $this->db->select("*");
        $this->db->from(self::TBL_GOODS);
        $this->db->where('order_id = '.$order_id);
        $this->db->order_by("goods_id","desc");
        $query = $this->db->get();
        return $query->result_array();
//        return $query->row_array();
    }
    public function update_order_error($data,$order_id){  //打回订单到调度状态
        $condition['order_id'] = $order_id;
        $condition['status'] = 29;
        $id = $this->db->where($condition)->update(self::TBL_ORDER,$data);
        if($id > 0){
            $goods_data = array('status'=>7);   //将商品的状态修改到7未发货
            $goods_condition['order_id'] = $order_id;
            return $this->db->where($goods_condition)->update(self::TBL_GOODS,$goods_data);
        }else{
            return $id;
        }
    }
    //回传已发货的全部数据
    public function backhaul_order_data_all(){
        $this->db->select("order_number oid, express_number pid, add_time ot");
        $this->db->from(self::TBL_ORDER);
        $this->db->where('status = 29');
        $this->db->order_by("order_id","asc");
        $query = $this->db->get();
        return $query->result_array();
    }
    //回传已发货的部分数据
    public function get_order($order_number){
        $this->db->select("order_number oid, express_number pid, add_time ot");
        $this->db->from(self::TBL_ORDER);
        $this->db->where('order_number = '.$order_number);
        $this->db->order_by("order_number","desc");
        $query = $this->db->get();
        $array = $query->row_array();
        $array['ostat'] = 2;
        return $array;
    }
    //同步后更改状态
    public function update_order_status($order_number){
        $condition['order_number'] = $order_number;
        $condition['status'] = 29;
        $data = array('status' => 30);
        return $this->db->where($condition)->update(self::TBL_ORDER,$data);
    }
    //获取当前状态的数量
    public function count_status($status){
        $condition['status'] = $status;
        return $this->db->where($condition)->count_all_results(self::TBL_ORDER);
    }
}