<?php
/**
 * Created by PhpStorm.
 * User: liangqiliang
 * Date: 2015/7/9
 * Time: 10:55
 */

class Order_model extends Common_Model{

    protected $fileds = array('order_id', 'order_number', 'buyer_name', 'buyer_address', 'buyer_post', 'is_invoice', 'add_time', 'status', 'express_name', 'express_number', 'buyer_comments', 'make_remarks', 'buyer_phone', 'invoice_content', 'total', 'discount', 'final_payment');

    function __construct(){
        parent::__construct();
    }

    /**
     *
     * 获取记录条数
     *
     */
    public function num_rows($status, $order_number = "", $start_time = "", $end_time = ""){
        $this->db->select('order_id');

        if(!empty($order_number)){
            $this->db->like('order_number',$order_number);
        }
        if(!empty($start_time)){
            $this->db->where('add_time >='.$start_time);
        }
        if(!empty($end_time)){
            $this->db->where('add_time <= '.$end_time);
        }
        $this->db->where('status',$status);
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    /*
     *
     * 获取多条数据
     *
     */
    public function get_data($status, $start = 0, $perpage = 10, $order_number = "", $start_time = "", $end_time = ""){
        $this->db->select("*");
        $this->db->from($this->table);
        if(!empty($order_number)){
            $this->db->like('order_number',$order_number);
        }
        if(!empty($start_time)){
            $this->db->where('add_time >='.$start_time);
        }
        if(!empty($end_time)){
            $this->db->where('add_time <= '.$end_time);
        }
        $this->db->where('status',$status);
        $this->db->order_by("order_id","desc");
        $this->db->limit($perpage, $start);
        $result = $this->db->get();
        return $result->result_array();
    }


    /*
     *
     * 获取单条数据
     *
     */
    public function get_data_info($order_id){
        $this->db->select("*");
        $this->db->from($this->table);
         $this->db->where('order_id',$order_id);
        $result = $this->db->get();
        return $result->row_array();
    }

    //获取带商品的订单信息
    public function get_order_goods($order_id){
        $this->db->select("*");
        $this->db->from($this->table);
        $this->db->where("order_id",$order_id);
        $result = $this->db->get();
        $order = $result->row_array();

        $this->db->select("*");
        $this->db->from("goods");
        $this->db->where("order_id",$order_id);
        $result2 = $this->db->get();
        $goods = $result2->result_array();
        if(!$order){
            return false;
        }else{
            $order['goods'] = $goods;
            return $order;
        }
    }

    //保存订单
    public function save_order($data){
        //先检测数据是否存在
        $this->db->select("order_id");
        $this->db->where(array('order_number'=>$data['order_number']));
        $this->db->from($this->table);
        $res = $this->db->get()->row_array();
        if($res && isset($res['order_id']))
            return $res['order_id'];

        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

}