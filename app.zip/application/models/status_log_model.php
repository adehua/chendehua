<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/7/10
 * Time: 15:57
 */

class Status_log_model extends Common_Model{

    protected $fileds = array('id','order_number','goods_name','pre_status','status','change_time');

    function __construct(){
        parent::__construct();
    }

    function log($log_data){
        $this->db->insert_batch($this->table, $log_data);
    }

}