<?php
/**
 * Created by PhpStorm.
 * User: liangqiliang
 * Date: 2015/7/9
 * Time: 11:15
 */

class Goods_model extends Common_Model{

    protected $fileds = array('goods_id','order_id','goods_name','size','count','page_count','technology','status', 'path');

    function __construct(){
        parent::__construct();
    }

    /**
     *
     * 获取记录条数
     *
     */
    public function num_rows(){
        $this->db->select('*');
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

    /*
     *
     * 根据订单id获取多条记录
     *
     */
    public function get_goods_by_id($order_id){
        $this->db->select('*');
        $this->db->from($this->table);
        $this->db->where('order_id',$order_id);
        $result = $this->db->get();
        return $result->result_array();
    }

    /*
     *
     * 根据good_id获取多条记录的状态
     *
     */
    public function get_status_by_goods_id($goods_id){
        $this->db->select("*");
        $this->db->from($this->table);
        $this->db->where_in("goods_id",$goods_id);
        $result = $this->db->get();
        return $result->result_array();
    }
     public function get_one_goods_id($goods_id){
        $this->db->select("*");
        $this->db->from($this->table);
        $this->db->where_in("goods_id",$goods_id);
        $result = $this->db->get();
        return $result->row_array();
    }

    //保存
    public function save_goods($data){
        //先检测数据是否存在
        $this->db->select("goods_id");
        $this->db->where(array('order_id'=>$data['order_id'], 'elid'=>$data['elid']));
        $this->db->from($this->table);
        $res = $this->db->get()->row_array();
        if($res && isset($res['goods_id']))
            return $res['goods_id'];
        
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    public function save_all($data){
        //先检测数据是否存在
        if(!isset($data[0]['order_id']))
            return false;

        $order_id = $data[0]['order_id'];
        $elid_arr = array();
        foreach ($data as $d)
        {
            $elid_arr[] = $d['elid'];
        }

        $this->db->select("goods_id, elid");
        $this->db->where(array('order_id'=>$order_id));
        $this->db->where_in('elid', $elid_arr);
        $this->db->from($this->table);
        $res = $this->db->get()->result_array();
        if($res){
            foreach($res as $r){
                foreach($data as $dk => $da){
                    if($r['elid'] == $da['elid']){
                        unset($data[$dk]);
                    }
                }
            }
        }
        if(empty($data)) return true;

        $this->db->insert_batch($this->table, $data);
        return $this->db->affected_rows();
    }
}