<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *  
 */

class Index_model extends CI_Model{
}