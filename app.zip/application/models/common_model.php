<?php
/**
 *
 * 模型基类
 * @author	zhngyi <loeye@foxmail.com>
 * @date	2011-11-21
 *
 */
class Common_model extends CI_Model
{
	/**
	 *
	 * 表名
	 * @var string
	 */
	protected $table = '';

	/**
	 *
	 * 数据表前缀
	 * @var string
	 */
	protected $prefix = '';

	/**
	 *
	 * 表中允许操作的字段
	 * @var array
	 */
	protected $fileds = array();

	public function __construct()
	{
		$this->get_table_name();
		parent::__construct();
	}

	/**
	 *
	 * 添加新纪录
	 * @param 	array $data
	 * @return	number
	 */
	public function add($data)
	{
		
		$datas = $this->check_data($data);
		if (empty($datas))
		return 0;
		if ($query = $this->db->insert($this->table,$datas))
		{
			if ($this->db->insert_id())
			return $this->db->insert_id();
			else
			return $this->db->affected_rows();
		}
		return 0;
	}

	/**
	 *
	 * 修改数据
	 * @param array $data
	 * @param mixed $where
	 * @return number
	 */
	public function update($data, $where)
	{


		$datas = $this->check_data($data);
		if (empty($datas))
		{
		//	echo "内容为空";
			return 0;
		}
		if ($query = $this->db->set($datas)->where($where)->update($this->table))
		{
		//	echo "hello";
			return $this->db->affected_rows();
		}
		//echo "执行失败";
		return 0;
	}

	/**
	 *
	 * Enter description here ...
	 * @param	mixed 	$where
	 * @return 	number
	 */
	public function del($where)
	{
		if ($query = $this->db->where($where)->delete($this->table))
			return $this->db->affected_rows();
		return 0;
	}

	/**
	 *
	 * 数据查询
	 * @param 	mixed 	$where
	 * @param 	string 	$fileds
	 * @param 	mixed 	$limit
	 * @param 	array 	$order array('','')
	 * @param 	mixed 	$group
	 * @return 	array
	 */
	public function get($where, $fileds='*', $limit=0, $order=array(), $group='')
	{
		$this->db->select($fileds)->from($this->table)->where($where);
		if ($order) $this->db->order_by($order[0], $order[1]);
		if ($group) $this->db->group_by($group);
		if ($limit)
		{
			if (is_array($limit))
			$this->db->limit((int )$limit[0], (int )$limit[1]);
			else
			$this->db->limit((int )$limit);
		}
		$query = $this->db->get();
		$result = $query->result_array();
			
		return $result;
	}

	/**
	 *
	 * 单个数据查询
	 * @param 	mixed 	$where
	 * @param 	string 	$fileds
	 * @return 	array
	 */
	public function getinfo($where, $fileds='*')
	{
		$this->db->select($fileds)->from($this->table)->where($where);
		$query = $this->db->get();
		$result = $query->row_array();
			
		return $result;
	}

	/**
	 * 
	 * 分页方法
	 * @param string $url
	 * @param int $total_rows
	 * @param int $cur_record
	 * @param int $per_page
	 */
	public function page($url, $total_rows, $cur_record=0, $per_page=10)
	{
		if ($total_rows <= $per_page || !(int )$total_rows)
		return '';
		$output = '<div class="pagination"><ul>';
		if ($cur_record==0)
		$output .= '<li class="disablepage">上一页</li>';
		else
		$output .= '<li class="disablepage"><a href="'. $url .'&per_page='. ($cur_record - $per_page) .'">上一页</a></li>';
			
		$page = ceil($total_rows / $per_page);
		$cur_page = ($cur_record / $per_page) + 1;
		
		if ($page <= 12)
		{
			for ($i = 1; $i <= $page; $i++ )
			{
				if ($i == $cur_page)
				{
					$output .= '<li class="currentpage">'. $i .'</li>';
				}
				else
				{
					$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a></li>';
				}
			}
		}
		else
		{
			if ($cur_page <7)
			{
				for ($i = 1; $i <= 10; $i++ )
				{
					if ($i == $cur_page)
					{
						$output .= '<li class="currentpage">'. $i .'</li>';
					}
					else if ($i == 10)
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a>...</li>';
					}
					else
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a></li>';
					}
				}
				for ($i = ($page - 3); $i <= $page; $i++)
				{
					$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a></li>';
				}
			}
			else if ($cur_page > ($page - 7))
			{
				for ($i = 1; $i < 4; $i++)
				{

					if ($i == 3)
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a>...</li>';
					}
					else
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a></li>';
					}
				}
				for ($i = ($page - 10); $i<= $page; $i++)
				{
					if ($i == $cur_page)
					{
						$output .= '<li class="currentpage">'. $i .'</li>';
					}
					else
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a></li>';
					}
				}
			}
			else
			{
				for ($i = 1; $i < 4; $i++)
				{

					if ($i == 3)
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a>...</li>';
					}
					else
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a></li>';
					}
				}
				for ($i = ($cur_page - 2); $i < ($cur_page + 3); $i++ )
				{
					if ($i == $cur_page)
					{
						$output .= '<li class="currentpage">'. $i .'</li>';
					}
					else if ($i == ($cur_page + 2))
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a>...</li>';
					}
					else
					{
						$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a></li>';
					}
				}
				for ($i = ($page - 3); $i <= $page; $i++)
				{
					$output .= '<li><a href="'. $url .'&per_page='. (($i - 1) * $per_page) .'">'. $i .'</a></li>';
				}
			}
		}
		
		if ($cur_page == $page)
		{
			$output .= '<li class="nextpage">下一页</li>';
		}
		else
		{
			$output .= '<li class="nextpage"><a href="'. $url .'&per_page='. ($cur_record + $per_page) .'">下一页</a></li>';
		}
		$output .= '</ul></div>';
		return $output;
	}

	/**
	 *
	 * 字段检测
	 * @param array $data
	 * @return array
	 */
	protected function check_data($data)
	{
		$datas = array();
		foreach ($data as $k=>$v)
		{
			if (in_array($k, $this->fileds))
			{
				$datas[$k] = $v;
			}
		}
		return $datas;
	}

	/**
	 *
	 * 获取数据表名
	 * return void
	 */
	protected function get_table_name()
	{
		if (!$this->table)
		{
			$class_name = get_class($this);
			$aname = explode('_', $class_name);
			array_pop($aname);
			$this->table = $this->prefix . strtolower(implode('_', $aname));
		}
	}
	
	/**
	* 字符串截取
	*
	* @param string $str
	* @param int $start
	* @param int $length
	* @param string $charset
	* @param true $suffix
	* @return string
	*/
	function msubstr($str, $start=0, $length, $charset="utf-8", $suffix=false)
	{
		if(mb_strlen($str,$charset) < ($length+$start))
		{
			return $str;
		}
		if($suffix)
		$suffixStr = "…";
		else
		$suffixStr = "";
	
		if(function_exists("mb_substr"))
		return mb_substr($str, $start, $length, $charset).$suffixStr;
		elseif(function_exists('iconv_substr')) {
			return iconv_substr($str,$start,$length,$charset).$suffixStr;
		}
		$re['utf-8']   = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
		$re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
		$re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
		$re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
		preg_match_all($re[$charset], $str, $match);
		$slice = join("",array_slice($match[0], $start, $length));
		return $slice.$suffixStr;
	}
	
	/**
	 * 
	 * 转义字符
	 * @param string $data
	 * @return string
	 */
	function daddslashes($data)
	{
		if (get_magic_quotes_gpc())
			return $data;
		return addslashes($data);
	}
	
	/**
	 * 
	 * 整数数组转化为IN可用的字符串
	 * @param array $arr
	 * @return string
	 */
	function intatostr($arr)
	{
		$str = '';
		if (!empty($arr))
		{
			foreach ($arr as $val)
			{
				if ((int )$val)
					$str .= ",". ((int )$val);
			}
			return trim($str,',');
		}
		return $str;
	}
	
	/**
	 * 
	 * 简单访问API
	 * @param string $url
	 * @return string
	 */
	function callapi($url)
	{
        //时间很长，影响正常使用   by kkchen
        /*
		if (($fp = @fopen($url, 'r')) !== false)
		{
			$content = '';
			while (!@feof($fp))
				$content .= @fread($fp, 8192);
			@fclose($fp);
			return $content;
		}
        */
		return false;
	}
}
