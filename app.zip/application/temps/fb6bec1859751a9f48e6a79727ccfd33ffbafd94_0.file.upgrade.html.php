<?php /* Smarty version 3.1.27, created on 2015-07-31 08:48:40
         compiled from "F:\wamp\www\fun_admin_print_com\print.kid.qq.com\application\views\default\upgrade.html" */ ?>
<?php
/*%%SmartyHeaderCode:1681955bb36681c6199_96530464%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fb6bec1859751a9f48e6a79727ccfd33ffbafd94' => 
    array (
      0 => 'F:\\wamp\\www\\fun_admin_print_com\\print.kid.qq.com\\application\\views\\default\\upgrade.html',
      1 => 1438332519,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1681955bb36681c6199_96530464',
  'variables' => 
  array (
    'base_url' => 0,
    'static_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_55bb366824aad8_71669040',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55bb366824aad8_71669040')) {
function content_55bb366824aad8_71669040 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1681955bb36681c6199_96530464';
echo $_smarty_tpl->getSubTemplate ("header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

	<div class="page-container row-fluid">
	<?php echo $_smarty_tpl->getSubTemplate ("lefter.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

		<!-- BEGIN PAGE -->
		<div class="page-content">
			<div class="container-fluid">
				<div class="row-fluid">
					<div class="span12">
						<ul class="breadcrumb" id="breadcrumbs">
							<li>
								<i class="fa fa-home" style="font-size: 1.3em;"></i>
								<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
">首页</a> 
								<i class="fa fa-angle-right" style="font-size: 1.3em;"></i>
							</li>
							<li><a href="javascript:void(0);">接单</a></li>
						</ul>
					</div>
				</div>
				<div class="row-fluid">
					<div class="span12">
						<div class="portlet box">
							<div class="portlet-title" style="text-align: center;position:relative;background-color:#428bca">
								<div class="caption" style="">Fun秀打印系统——在线更新</div>
								<div class="tools" style="position: absolute;top: 7px;right: 10px;">
									<a href="javascript:;" class="collapse"></a>
									<a href="javascript:;" class="reload"></a>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				<div class="row-fluid" style="text-align:center">
					<a href="javascript:void(0);" class="btn red" id="upgrade" style="margin: 3px"><!-- <i class="fa fa-arrow-circle-o-right" style="font-size:1.2em"></i> -->在线更新</a>
				</div>
			</div>
		</div>
	</div>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery-migrate-1.2.1.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!-- IMPORTANT! Load jquery-ui-1.10.1.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery-ui-1.10.1.custom.min.js" type="text/javascript"><?php echo '</script'; ?>
>      
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/excanvas.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/respond.min.js"><?php echo '</script'; ?>
>  
<![endif]-->   
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.slimscroll.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.blockui.min.js" type="text/javascript"><?php echo '</script'; ?>
>  
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.cookie.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.uniform.min.js" type="text/javascript" ><?php echo '</script'; ?>
>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/select2.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.dataTables.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/DT_bootstrap.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.fancybox.pack.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/icheck.min.js"><?php echo '</script'; ?>
>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/app.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/search.js"><?php echo '</script'; ?>
>
<!--<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/table-editable.js"><?php echo '</script'; ?>
>    -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/fun_page.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
var base_url = '<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
';

	$("#upgrade").click(function(){
		$.ajax({
            url: base_url+'/upgrade/update',
            type: 'get',
            dataType: "json",
            beforeSend: function () {
	            var str_html= '<div class="fun_shade fun_print0"></div><div class="fun_maker_data_info fun_print5" style="display:block"><p>更新代码中...</p></div>';
	            $("body").append(str_html); //显示弹层
	        },
            success: function (data) {
            	$(".fun_shade").remove();
                var str_html= '<div class="fun_shade fun_print0"></div><div class="fun_maker_data_info fun_print5" style="display:block"><p>'+data.data+'</p></div>';
	            $("body").append(str_html); //显示弹层
	            t = setTimeout('fun_remove()',3000); //3秒以后自动刷新
            },
        });
	})

<?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>