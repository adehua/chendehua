<?php /* Smarty version 3.1.27, created on 2015-07-31 07:28:14
         compiled from "F:\wamp\www\fun_admin_print_com\print.kid.qq.com\application\views\default\header.html" */ ?>
<?php
/*%%SmartyHeaderCode:1127155bb238eae0ae5_91068997%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '314c4b0efc95a76ecd78b24bf6a7799e5bc5940d' => 
    array (
      0 => 'F:\\wamp\\www\\fun_admin_print_com\\print.kid.qq.com\\application\\views\\default\\header.html',
      1 => 1438164154,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1127155bb238eae0ae5_91068997',
  'variables' => 
  array (
    'static_url' => 0,
    'base_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_55bb238eb20036_89149646',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55bb238eb20036_89149646')) {
function content_55bb238eb20036_89149646 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '1127155bb238eae0ae5_91068997';
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="zh" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="zh" class="ie9"> <![endif]-->
<!--[if !IE]>
<!--> 
	<html lang="zh"> 
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">

	<title>Fun秀印厂系统</title>
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<!-- BEGIN GLOBAL MANDATORY STYLES -->
	<link href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/bootstrap-responsive.min.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/font-awesome.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/style-metro.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/style.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/style-responsive.css" rel="stylesheet" type="text/css"/>
	<link href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/default.css" rel="stylesheet" type="text/css" id="style_color"/>
	<link href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/uniform.default.css" rel="stylesheet" type="text/css"/>
	<!-- END GLOBAL MANDATORY STYLES -->
	<!-- BEGIN PAGE LEVEL STYLES -->
	<!-- 其他页面的css-->
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/select2_metro.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/DT_bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/DT_bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/datepicker.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/jquery.fancybox.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/search.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/square/_all.css"/><!-- input插件 样式 -->
	<!-- 首页的css-->
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/jquery.gritter.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/daterangepicker.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/fullcalendar.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/jqvmap.css" media="screen"/>
	<link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/jquery.easy-pie-chart.css" media="screen"/>
	<!-- link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/responsive-tables.css" media="screen"/> -->

	<!-- css -->
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
css/main.css" />
	<!-- END PAGE LEVEL STYLES -->
	<link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
image/favicon.ico" />
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery-1.10.1.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!-- 	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/responsive-tables.js" type="text/javascript"><?php echo '</script'; ?>
> -->
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/fun.js" type="text/javascript"><?php echo '</script'; ?>
>
</head>
 
<!--[if lt IE 9]>
<style>
.fun_print0{background:#000;filter: alpha(opacity=50);  -moz-opacity:0.5;  opacity: 0.5;}
.fun_print1,.fun_print3{top:35%;left:38%;}
.fun_print2{top:25%;left:35%;}
.fun_print4{left:35%;}
.fun_print3 p{left:30%;top:40%;}
.fun_print2 .fun_maker_yes{left:42%;}
.fun_print3 .fun_maker_yes{left:42%;}
.page-sidebar {
  position: absolute;
  width: 225px;
}
</style>
<![endif]-->

 

<body class="page-header-fixed">
	<!-- BEGIN HEADER -->
	<div class="header navbar navbar-inverse navbar-fixed-top">
		<!-- BEGIN TOP NAVIGATION BAR -->
		<div class="navbar-inner">
			<div class="container-fluid">
				<!-- BEGIN LOGO -->
				
				<a class="brand" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
">
				<i class="fa fa-qq" style="color:#fff;font-size:1.3em;"></i>
				Fun秀打印系统
					<!-- <img src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
image/logo.png" alt="logo" /> -->
				</a>
				<!-- END LOGO -->
				<!-- BEGIN RESPONSIVE MENU TOGGLER -->
				<a href="javascript:;" class="btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
				<img src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
image/menu-toggler.png" alt="" />
				</a>          
				<!-- END RESPONSIVE MENU TOGGLER --> 
			</div>
		</div>
		<!-- END TOP NAVIGATION BAR -->
	</div>
<?php }
}
?>