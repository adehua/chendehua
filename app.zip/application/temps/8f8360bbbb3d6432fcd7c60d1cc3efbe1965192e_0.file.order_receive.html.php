<?php /* Smarty version 3.1.27, created on 2015-07-31 07:28:39
         compiled from "F:\wamp\www\fun_admin_print_com\print.kid.qq.com\application\views\default\order_receive.html" */ ?>
<?php
/*%%SmartyHeaderCode:2785855bb23a713cb16_05279148%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8f8360bbbb3d6432fcd7c60d1cc3efbe1965192e' => 
    array (
      0 => 'F:\\wamp\\www\\fun_admin_print_com\\print.kid.qq.com\\application\\views\\default\\order_receive.html',
      1 => 1438311483,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2785855bb23a713cb16_05279148',
  'variables' => 
  array (
    'base_url' => 0,
    'order_number' => 0,
    'start_time' => 0,
    'end_time' => 0,
    'data' => 0,
    'order' => 0,
    'goods' => 0,
    'perpage' => 0,
    'static_url' => 0,
    'page' => 0,
    'page_sum' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_55bb23a72af034_71274143',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55bb23a72af034_71274143')) {
function content_55bb23a72af034_71274143 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_date_format')) require_once 'F:\\wamp\\www\\fun_admin_print_com\\print.kid.qq.com\\application\\libraries\\Smarty\\plugins\\modifier.date_format.php';

$_smarty_tpl->properties['nocache_hash'] = '2785855bb23a713cb16_05279148';
echo $_smarty_tpl->getSubTemplate ("header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

	<div class="page-container row-fluid">
	<?php echo $_smarty_tpl->getSubTemplate ("lefter.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

		<!-- BEGIN PAGE -->
		<div class="page-content">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- <div id="portlet-config" class="modal hide">
				<div class="modal-header">
					<button data-dismiss="modal" class="close" type="button"></button>
					<h3>portlet Settings</h3>
				</div>
				<div class="modal-body">
					<p>Here will be a configuration form</p>
				</div>
			</div> -->
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- BEGIN PAGE CONTAINER-->        
			<div class="container-fluid">
				<!-- BEGIN PAGE HEADER-->
				<div class="row-fluid">
					<div class="span12">
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<ul class="breadcrumb" id="breadcrumbs">
							<li>
								<i class="fa fa-home" style="font-size: 1.3em;"></i>
								<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
">首页</a> 
								<i class="fa fa-angle-right" style="font-size: 1.3em;"></i>
							</li>
							<li><a href="javascript:void(0);">接单</a></li>
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
				<!-- END PAGE HEADER-->
				<!-- BEGIN PAGE CONTENT   -->

				<div class="row-fluid">
					<div class="span12">
						<!-- BEGIN EXAMPLE TABLE PORTLET-->
						<div class="portlet box">
							<div class="portlet-title" style="text-align: center;position:relative;background-color:#428bca">
								<div class="caption" style="">Fun秀打印系统——接单</div>
								<div class="tools" style="position: absolute;top: 7px;right: 10px;">
									<a href="javascript:;" class="collapse"></a>
									<a href="javascript:;" class="reload"></a>
								</div>
							</div>
							<div class="portlet-body" style="position: relative;">
								<div class="clearfix search_order">
									<div class="search_order_time">
										<div class="search_order_sn">
											<span class="mobile_hide">订单号：</span>
											<input class="input-small " id="order_barcode_search" type="text" name="order_number" value="" placeholder="<?php if ($_smarty_tpl->tpl_vars['order_number']->value) {
echo $_smarty_tpl->tpl_vars['order_number']->value;
} else { ?>点击搜索订单<?php }?>">
										</div>
										<span class="mobile_hide">日期：</span>
										<div class="input-append date date-picker" data-date="<?php if ($_smarty_tpl->tpl_vars['start_time']->value) {
echo $_smarty_tpl->tpl_vars['start_time']->value;
}?>" data-date-format="yyyy-mm-dd" data-date-viewmode="years"><input class="m-wrap m-ctrl-medium input-small start_time" size="16" type="text" name="start_time" value="<?php if ($_smarty_tpl->tpl_vars['start_time']->value) {
echo $_smarty_tpl->tpl_vars['start_time']->value;
}?>" data-date-format="yyyy-mm-dd" placeholder="选择起止日期"><span class="add-on"><i class="fa fa-calendar" style="font-size: 1.4em"></i></span></div>
										<div class="input-append date date-picker" data-date="<?php if ($_smarty_tpl->tpl_vars['end_time']->value) {
echo $_smarty_tpl->tpl_vars['end_time']->value;
} else {
echo smarty_modifier_date_format(time(),'%Y-%m-%d');
}?>" data-date-format="yyyy-mm-dd" data-date-viewmode="years"><input class="m-wrap m-ctrl-medium input-small end_time" size="16" type="text" name="end_time" value="<?php if ($_smarty_tpl->tpl_vars['end_time']->value) {
echo $_smarty_tpl->tpl_vars['end_time']->value;
} else {
echo smarty_modifier_date_format(time(),'%Y-%m-%d');
}?>" data-date-format="yyyy-mm-dd" ><span class="add-on"><i class="fa fa-calendar" style="font-size: 1.4em"></i></span></div>
										<a href="javascript:void(0);" class="btn blue search"><i class="fa fa-search"></i> 搜索</a>
									</div>
								</div>
								<ul class="fun_ul_table" id="sample_editable_1">
									<li style="display:table;">
										<div style="width:8%;">订单号</div>
										<div style="width:9%;">时间</div>
										<div style="width:20%;">用户信息</div>
										<div style="width:5%;">我要预览</div>
										<div style="width:24%;">打印文件</div>
										<div style="width:6%;">是否已打印</div>
										<div style="width:10%;">发票</div>
										<div style="width:18%;">操作</div>
									</li>
									<?php
$_from = $_smarty_tpl->tpl_vars['data']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['order'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['order']->_loop = false;
$_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['order']->value) {
$_smarty_tpl->tpl_vars['order']->_loop = true;
$foreach_order_Sav = $_smarty_tpl->tpl_vars['order'];
?>
									<li class="order_info_data order_info_data_<?php echo $_smarty_tpl->tpl_vars['order']->value['order_id'];?>
 remove_data_<?php echo $_smarty_tpl->tpl_vars['order']->value['order_id'];?>
">
										<div style="width:8%;"><input type="hidden" id="order_id" value="<?php echo $_smarty_tpl->tpl_vars['order']->value['order_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['order']->value['order_number'];?>
</div>
										<div style="width:9%;"><?php echo $_smarty_tpl->tpl_vars['order']->value['add_time'];?>
</div>
										<div style="width:20%;">
											<ul class="user_info order_ul">
												<li><span>姓名：</span><span><?php echo $_smarty_tpl->tpl_vars['order']->value['buyer_name'];?>
</span></li>
												<li><span>电话：</span><span><?php echo $_smarty_tpl->tpl_vars['order']->value['buyer_tel'];
if ($_smarty_tpl->tpl_vars['order']->value['buyer_phone']) {?><br>座机：<?php echo $_smarty_tpl->tpl_vars['order']->value['buyer_phone'];
}?></span></li>
												<li><span>地址：</span><span><?php echo $_smarty_tpl->tpl_vars['order']->value['buyer_address'];?>
</span></li>
											</ul>
										</div>
										<div style="width:35%;">
											<ul class="child_ul" style="padding:0px;margin:0px;">
		                                        <?php
$_from = $_smarty_tpl->tpl_vars['order']->value['goods'];
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['goods'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['goods']->_loop = false;
$_smarty_tpl->tpl_vars['k1'] = new Smarty_Variable;
foreach ($_from as $_smarty_tpl->tpl_vars['k1']->value => $_smarty_tpl->tpl_vars['goods']->value) {
$_smarty_tpl->tpl_vars['goods']->_loop = true;
$foreach_goods_Sav = $_smarty_tpl->tpl_vars['goods'];
?>
													<li>
														<div style="width:14%;text-align:center;" class="paddingright"><a href="order_receive/viewGoods/<?php echo $_smarty_tpl->tpl_vars['goods']->value['goods_id'];?>
" target="_blank">预览</a></div>
														<div style="width:69%;position: relative;" class="paddingstyle">
															<input type="checkbox" class="checkbox_dow" name="check_<?php echo $_smarty_tpl->tpl_vars['order']->value['order_id'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['goods']->value['goods_id'];?>
" style="display:none;" <?php if ($_smarty_tpl->tpl_vars['goods']->value['status'] < 4) {?> checked <?php }?>><a href="javascript:void(0);" style="margin-left:30px;"><?php echo $_smarty_tpl->tpl_vars['goods']->value['goods_name'];?>
</a>
														</div>
														<div style="width:17%;text-align:center;">
															<?php if ($_smarty_tpl->tpl_vars['goods']->value['status'] < 4) {?>
			                                                    <span class="label label-default is_label">否</span>
			                                                <?php } else { ?>
			                                                    <span class="label label-important is_label">是</span>
			                                                <?php }?>
														</div>
													</li>
												<?php
$_smarty_tpl->tpl_vars['goods'] = $foreach_goods_Sav;
}
?>
											</ul>
										</div>
										<div style="width:10%;"><?php if ($_smarty_tpl->tpl_vars['order']->value['is_invoice'] == 0) {?>无发票<?php } elseif ($_smarty_tpl->tpl_vars['order']->value['is_invoice'] == 1) {?>个人发票<?php } else {
if ($_smarty_tpl->tpl_vars['order']->value['invoice_content'] == '') {?>个人发票<?php } else {
echo $_smarty_tpl->tpl_vars['order']->value['invoice_content'];
}
}?></div>
										<div style="width:18%;">
											<a href="javascript:void(0);" class="btn green print_order" style="margin: 3px">打印制作单</a>
											<a href="javascript:void(0);" class="btn green go_list_order" style="margin: 3px">下一步</a>
										</div>
									</li>
									<li class="remove_data_<?php echo $_smarty_tpl->tpl_vars['order']->value['order_id'];?>
">
										<p class="fun_ul_table_desc">
                                        	<span style="">用户留言：</span>
                                        	<?php if ($_smarty_tpl->tpl_vars['order']->value['buyer_comments']) {
if ($_smarty_tpl->tpl_vars['order']->value['buyer_comments']) {?><span class="order_info_postscript" style=""><?php echo $_smarty_tpl->tpl_vars['order']->value['buyer_comments'];?>
</span><?php } else { ?><span class="order_info_postscript" style="color:#fff;">.</span><?php }
} else { ?><span class="order_info_postscript" style="color:#fff;">.</span><?php }?>
                                        	<span style="">制作备注：</span>
                                        	<span class="order_info_printpostscript order_info_printpostscript_<?php echo $_smarty_tpl->tpl_vars['order']->value['order_id'];?>
" style="" contenteditable="true"><?php echo $_smarty_tpl->tpl_vars['order']->value['make_remarks'];?>
</span>
                                        </p>
									</li>
									<?php
$_smarty_tpl->tpl_vars['order'] = $foreach_order_Sav;
}
?>
								</ul>
								<div class="fun_page" style="">	</div> <!-- 分页 -->
								<form class="form" style="position: absolute; right: 11px; bottom: 7px; margin: 0;">
									<span style="line-height:40px;" class="mobile_hide">每页条数：</span>
									<select class="form-control" id="select_perpage" style="width: 80px;">
                                        <option value="10" <?php if ($_smarty_tpl->tpl_vars['perpage']->value == 10) {?> selected <?php }?>>10</option>
                                        <option value="30"<?php if ($_smarty_tpl->tpl_vars['perpage']->value == 30) {?> selected <?php }?>>30</option>
                                        <option value="50"<?php if ($_smarty_tpl->tpl_vars['perpage']->value == 50) {?> selected <?php }?>>50</option>
                                        <option value="100"<?php if ($_smarty_tpl->tpl_vars['perpage']->value == 100) {?> selected <?php }?>>100</option>
									</select>
								</form>
							</div>
						</div>
						<!-- END EXAMPLE TABLE PORTLET-->
					</div>
				</div>
				<!-- END PAGE CONTENT -->
			</div>
			<!-- END PAGE CONTAINER-->
		</div>
		<!-- END PAGE -->
	</div>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery-migrate-1.2.1.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!-- IMPORTANT! Load jquery-ui-1.10.1.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery-ui-1.10.1.custom.min.js" type="text/javascript"><?php echo '</script'; ?>
>      
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!--[if lt IE 9]>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/excanvas.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/respond.min.js"><?php echo '</script'; ?>
>  
<![endif]-->   
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.slimscroll.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.blockui.min.js" type="text/javascript"><?php echo '</script'; ?>
>  
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.cookie.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.uniform.min.js" type="text/javascript" ><?php echo '</script'; ?>
>
<!-- END CORE PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/select2.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.dataTables.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/DT_bootstrap.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/bootstrap-datepicker.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/jquery.fancybox.pack.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/icheck.min.js"><?php echo '</script'; ?>
>
<!-- END PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL SCRIPTS -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/app.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/search.js"><?php echo '</script'; ?>
>
<!--<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/table-editable.js"><?php echo '</script'; ?>
>    -->
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['static_url']->value;?>
js/fun_page.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
>
    var page_now = <?php echo $_smarty_tpl->tpl_vars['page']->value;?>
; //当前的页数
    var pages = <?php echo $_smarty_tpl->tpl_vars['page_sum']->value;?>
;    //总页数
    var order_number = '<?php echo $_smarty_tpl->tpl_vars['order_number']->value;?>
';
    var start_time = '<?php echo $_smarty_tpl->tpl_vars['start_time']->value;?>
';
    var end_time = '<?php echo $_smarty_tpl->tpl_vars['end_time']->value;?>
';
    var perpage = '<?php echo $_smarty_tpl->tpl_vars['perpage']->value;?>
';
    var base_url = '<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
';
    var t;
    
	jQuery(document).ready(function() {       
		App.init();
		Search.init();
		$('.checkbox_dow').iCheck({	//接单-打印复选框样式    
			checkboxClass: 'icheckbox_square-green',	//颜色有Black,Red,Green,Blue,Aero,Grey,Orange,Yellow,Pink,Purple
			increaseArea: '20%' // optional
		});
		//$('.checkbox_dow').iCheck('check');
	});

    //选择分页条数
    $("#select_perpage").change(function(){
        perpage = $(this).val();
        url = base_url+"/order_receive?order_number="+order_number+"&start_time="+start_time+"&end_time="+end_time+"&perpage="+perpage+"&page=1";
        window.location.href=url;
    });

	/* 分页 */
	var url = "order_receive?order_number="+order_number+"&start_time="+start_time+"&end_time="+end_time+"&perpage="+perpage+"&page=";	//分页URL
	var page_html = fun_page(page_now,pages,url);
	$(".fun_page").append(page_html);

    //搜索
    $(".search").click(function(){
        order_number = $(".search_order_sn input").val();
        start_time = $(".start_time").val();
        end_time = $(".end_time").val();
        perpage = $("#select_perpage").val();
        url = base_url+"/order_receive?order_number="+order_number+"&start_time="+start_time+"&end_time="+end_time+"&perpage="+perpage+"&page=1";
        window.location.href=url;
    });

    //打印制作单
    $('.print_order').click(function(){
        var order_id = $(this).parents('li').find("#order_id").val();
        $.ajax({
            url:base_url+"/order_receive/getOrderInfo",
            data:{order_id:order_id},
            type:"POST",
            dataType:"json",
            success: function (data) {
                if(data.err == 1){//如果成功
                	data = data.msg;
                	var pop_html = '<div class="fun_shade fun_print0"></div><div class="fun_print4" style="top:'+$(document).scrollTop() +'px"><div id="printdiv" style="text-align: left;"><div style="padding: 50px;" id="printdivdiv">';
                	pop_html += '<div style="font-size:20px;;text-align:center;">制作单</div><div class="margin30">订单号：'+data.order_number+'</div><table class="table make_table" style="border: 1px solid #ddd;"><thead><tr><th width="20%;" style="text-align:center;padding: 9px 10px;">作品名称</th><th width="10%;" style="text-align:center;padding: 9px 10px;">数量</th><th width="27%;" style="text-align:center;padding: 9px 10px;">装订</th><th width="23%;" style="text-align:center;padding: 9px 10px;">纸张</th><th width="20%;" style="text-align:center;padding: 9px 10px;">尺寸</th></tr></thead><tbody id="printdiv_info">';
                	for(var i = 0;i<data.goods.length;i++){
                		pop_html += '<tr style=""><td style="padding: 9px 10px;">'+data.goods[i].goods_name+'</td><td style="padding: 9px 10px;">'+data.goods[i].count+'</td><td style="padding: 9px 10px;">'+data.goods[i].technology+'</td><td style="padding: 9px 10px;">'+data.goods[i].paper+'</td><td style="padding: 9px 10px;">'+data.goods[i].size+'</td></tr>'
                	}
                	if(data.is_invoice == 0){
                		pop_html += '</tbody></table><div class="margin30">发票：无发票</div><div class="margin30"><p>姓名：'+data.buyer_name+'</p>';
                	}else if(data.is_invoice == 1){
                		pop_html += '</tbody></table><div class="margin30">发票：个人发票</div><div class="margin30"><p>姓名：'+data.buyer_name+'</p>';
                	}else{
                		if(data.invoice_content == "") data.invoice_content = "个人发票";
                		pop_html += '</tbody></table><div class="margin30">发票：'+data.invoice_content+'</div><div class="margin30"><p>姓名：'+data.buyer_name+'</p>';
                	}
                	if(data.buyer_tel.length > 0)
                		pop_html += '<p>手机：'+data.buyer_tel+'</p>';
                	if(data.buyer_phone.length > 0)
                		pop_html += '<p>座机：'+data.buyer_phone+'</p>';
                	pop_html += '</div><div  class="margin30">时间：'+data.add_time+'</div></div></div><a href="javascript:void(0);" class="fun_maker_yes blue" onclick="printdiv();"><i class="fa fa-check"></i>确定</a><a href="javascript:void(0);" class="fun_maker_no cancel_print green" onclick="fun_maker_print_no()"><i class="fa fa-remove"></i>取消</a></div>'
                	fun_remove();
                    $("body").append(pop_html);
        			//t = setTimeout('fun_remove()',15000); //5秒以后自动取消、关闭页面
        			var top =$(document).scrollTop() + $(window).height()/2 - ($(".fun_print4").height()+100)/2;
        			if(top <0) top = 0;
        			$(".fun_print4").css("top",top);
                }else{
                    fun_error(data.msg);
                }
            }
        });
    });

    function order_print_yes(id){
        //TODO
        fun_remove();
    }

    //下一步
    $('.go_list_order').click(function(){
        var order_id = $(this).parents('li').find("#order_id").val();
        var order_number = $(this).parents('li').find("div").eq(0).text();
        var pop_html = '<div class="fun_shade fun_print0"></div><div class="fun_maker_print fun_print1"><p>确定将订单'+order_number+'转发至印刷？</p><a href="javascript:void(0);" class="fun_maker_yes blue" onclick="fun_maker_print_yes('+order_id+')"><i class="fa fa-check"></i>确定</a><a href="javascript:void(0);" class="fun_maker_no green" onclick="fun_maker_print_no()"><i class="fa fa-remove"></i>取消</a></div>';
//        console.log(order_id);
//        console.log(order_number);
fun_remove();
        $("body").append(pop_html);
        t = setTimeout('fun_remove()',5000); //5秒以后自动取消、关闭页面
    });

    //取消
    function fun_maker_print_no(){
        fun_remove();
    };

    //下一步
    function fun_maker_print_yes(id){
        update_next(id);
        fun_remove();
    }

    function update_next(id){
        var make_remarks = $(".order_info_printpostscript_"+id).text();
//        console.log()
        var checked_goods = new Array();
        $("input[name='check_"+id+"']:checked").each(function(){
            checked_goods.push(parseInt($(this).val()));
        });
//        console.log(checked_goods);
        $.ajax({
            url:base_url+"/order_receive/updateStatus",
            data:{
                order_id:id,
                make_remarks:make_remarks,
                checked_goods:checked_goods
            },
            type:"POST",
            dataType:"json",
            success: function (data) {
                if(data.err == 1){//如果成功
                    success_status(id);
                }else{
                    fun_error(data.msg);
                }
            }
        });
    }
//定时更新
var status = 20;
var ob = $('.order_receive_new_sum');
var new_sum = setInterval("setinterval_status("+status+",ob)",5000);
setinterval_status(status,ob);
new_sum;

<?php echo '</script'; ?>
>
<?php echo $_smarty_tpl->getSubTemplate ("footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>