<?php /* Smarty version 3.1.27, created on 2015-07-31 07:28:14
         compiled from "F:\wamp\www\fun_admin_print_com\print.kid.qq.com\application\views\default\lefter.html" */ ?>
<?php
/*%%SmartyHeaderCode:440455bb238eb334e7_36486979%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd8dc23bf01fe084cf0cea61e06e3cf5c14cabf8c' => 
    array (
      0 => 'F:\\wamp\\www\\fun_admin_print_com\\print.kid.qq.com\\application\\views\\default\\lefter.html',
      1 => 1438164155,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '440455bb238eb334e7_36486979',
  'variables' => 
  array (
    'currentApp' => 0,
    'base_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_55bb238eb6bfd0_30587924',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55bb238eb6bfd0_30587924')) {
function content_55bb238eb6bfd0_30587924 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '440455bb238eb334e7_36486979';
?>
		<div class="page-sidebar nav-collapse collapse">
			<ul class="page-sidebar-menu">
				<li>
					<div class="sidebar-toggler hidden-phone"></div>
				</li>
				<li class="start <?php if ($_smarty_tpl->tpl_vars['currentApp']->value == 'index') {?>active<?php }?>">
					<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
">
					<i class="fa fa-home"></i> 
					<span class="title">首页</span>
					</a>
				</li>
				<li class="start <?php if ($_smarty_tpl->tpl_vars['currentApp']->value == 'index1') {?>active<?php }?>">
					<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/download">
					<i class="fa fa-download"></i> 
					<span class="title">获取数据</span>
					</a>
				</li>
				<li class="start <?php if ($_smarty_tpl->tpl_vars['currentApp']->value == 'order_receive') {?>active<?php }?>">
					<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/order_receive">
					<i class="fa fa-list"></i> 
					<span class="title">接单</span>
					<span class="badge badge-primary order_receive_new_sum" style="background-color: #fff;color:#000"></span>
					</a>
				</li>
				<li class="start <?php if ($_smarty_tpl->tpl_vars['currentApp']->value == 'order_print') {?>active<?php }?>">
					<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/order_print">
					<i class="fa fa-print"></i> 
					<span class="title">印刷</span>
					<span class="badge badge-primary order_print_new_sum" style="background-color: #fff;color:#000"></span>
					</a>
				</li>
				<li class="start <?php if ($_smarty_tpl->tpl_vars['currentApp']->value == 'order_make') {?>active<?php }?>">
					<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/order_make">
					<i class="fa fa-book"></i> 
					<span class="title">制作</span>
					<span class="badge badge-primary order_make_new_sum" style="background-color: #fff;color:#000"></span>
					</a>
				</li>
				<li class="start <?php if ($_smarty_tpl->tpl_vars['currentApp']->value == 'order_express') {?>active<?php }?>">
					<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/order_express">
					<i class="fa fa-plane"></i> 
					<span class="title">调度</span>
					<span class="badge badge-primary order_express_new_sum" style="background-color: #fff;color:#000"></span>
					</a>
				</li>
				<li class="start <?php if ($_smarty_tpl->tpl_vars['currentApp']->value == 'order_list') {?>active<?php }?>">
					<a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
/order_list">
					<i class="fa fa-th-list"></i> 
					<span class="title">订单列表</span>
					<span class="badge badge-primary order_list_new_sum" style="background-color: #fff;color:#000"></span>
					</a>
				</li>
			</ul>
			<!-- END SIDEBAR MENU -->
		</div>
<!-- END SIDEBAR -->
<?php }
}
?>