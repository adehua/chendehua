<?php /* Smarty version 3.1.27, created on 2015-07-31 07:28:14
         compiled from "F:\wamp\www\fun_admin_print_com\print.kid.qq.com\application\views\default\footer.html" */ ?>
<?php
/*%%SmartyHeaderCode:2338955bb238eba9b92_96770458%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cc82c69b6ee90d31a0f669622573c34196315484' => 
    array (
      0 => 'F:\\wamp\\www\\fun_admin_print_com\\print.kid.qq.com\\application\\views\\default\\footer.html',
      1 => 1438164154,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2338955bb238eba9b92_96770458',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_55bb238ebadfe3_49917717',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_55bb238ebadfe3_49917717')) {
function content_55bb238ebadfe3_49917717 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '2338955bb238eba9b92_96770458';
?>
<?php echo '<script'; ?>
>

<?php echo '</script'; ?>
>
<!-- BEGIN FOOTER -->
	<div class="footer">
		<div class="footer-inner">
			Copyright © 1998 - 2015 Tencent. All Rights Reserved
		</div>
		<div class="footer-tools">
			<span class="go-top">
			<i class="fa fa-angle-up"></i>
			</span>
		</div>
	</div>
<?php echo '<script'; ?>
 type="text/javascript">  
/*var _gaq = _gaq || [];  _gaq.push(['_setAccount', 'UA-37564768-1']);  _gaq.push(['_setDomainName', 'keenthemes.com']);  _gaq.push(['_setAllowLinker', true]);  _gaq.push(['_trackPageview']);  (function() {    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;    ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);  })(); */
<?php echo '</script'; ?>
>
</body>
<!-- END BODY -->
</html><?php }
}
?>