<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/* 验证传过来的时间*/
function get_date_info($date)
{
    if (empty($date)) {
        return false;
    }
    $data = explode('-', $date);
    if (count($data) != 3) {  //时间转转化成数组的长度需要 = 3
        return false;
    }
    // foreach($data as $k => $v){ //int
    //     $data[$k] = $v;
    // }
    if ($data[0] <= 0 || $data[1] <= 0 || $data[2] <= 0 || $data[1] > 12 || $data[2] > 31) {
        return false;
    }
    $date = implode('-', $data);
    return $date;
}

//加密
function rsa_data($backhaul_data)
{
    if (empty($backhaul_data)) {
        echo json_encode(array('res' => 0, 'data' => '同步数据失败'));
        exit();
    }

    $ci = & get_instance();
    $ci->load->library('RSA');   //调取RSA
    $tencent_public = ROOT_PATH . "/application/libraries/tencent_public.crt";
    $tencent_private = ROOT_PATH . "/application/libraries/tencent_private.pfx";
    $rsa = new RSA($tencent_public, $tencent_private);
    //第一步 生成json的data数据
    $json_data = json_encode($backhaul_data);
    //第二步 rsa加密data
    $data = $rsa->encrypt($json_data);
    //第三步 生成sign
    //（1）对data数据进行base64编码
    //（2）对编码后的数据进行rsa的数字签名
    $sign = $rsa->sign(base64_decode($data));
    //（3）对加密结果进行base64编码
    //$sign = base64_decode(base64_encode($rsa_sign));
    //第四步 url传输urlencode
    $ret = array(
        'data' => urlencode($data),
        'sign' => urlencode($sign)
    );
    return $ret;
}

//取得文件扩展
function fileext($filename) {
    return strtolower(trim(substr(strrchr($filename, '.'), 1, 10)));
}

//解压
function unzip_file($zipfile, $savepath){
    $zip = new ZipArchive();
    chmod($zipfile, 0777);
    $res = $zip->open($zipfile);
    if($res === true){
        $zip->extractTo($savepath);
        $zip->close();
        return true;
    }else{
        return false;
    }
}
//压缩
function addFileToZip($path, $zip, $rootpath) {
    $handler = opendir($path); //打开当前文件夹由$path指定。
    /*
    循环的读取文件夹下的所有文件和文件夹
    其中$filename = readdir($handler)是每次循环的时候将读取的文件名赋值给$filename，
    为了不陷于死循环，所以还要让$filename !== false。
    一定要用!==，因为如果某个文件名如果叫'0'，或者某些被系统认为是代表false，用!=就会停止循环
    */
    while (($filename = readdir($handler)) !== false) {
        if ($filename != "." && $filename != "..") {//文件夹文件名字为'.'和‘..’，不要对他们进行操作
            if (is_dir($path . "/" . $filename)) {// 如果读取的某个对象是文件夹，则递归
                addFileToZip($path . "/" . $filename, $zip, $rootpath);
            } else { //将文件加入zip对象
                $file_info_arr= pathinfo($path . "/" . $filename);
                $file_info_arr_dirname = str_replace($rootpath,'',$file_info_arr['dirname']);
                if(empty($file_info_arr_dirname)){
                    $zip->addFile($path . "/" . $filename, $file_info_arr_dirname.$filename);
                }else{
                    $zip->addFile($path . "/" . $filename, substr($file_info_arr_dirname."/".$filename,1));
                }
            }
        }
    }
    @closedir($path);
}
//根据状态获取不同的控制器
function app_serach($status){
        switch ($status) {
            case 20:
                return 'order_receive';
                break;
            case 21:
                return 'order_print';
                break;
            case 22:
                return 'order_make';
                break;
            case 25:
                return 'order_express';
                break;
            case 29:
                return 'order_list';
                break;
            case 30:
                return 'order_list';
                break;
            default:
                return 'order_receive';
                break;
        }
    }